﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

public class SavedDataCollectionCode : MonoBehaviour {

    public Question[] questionBank;

    public TextAsset[] questionPages;
    public TextAsset[] answer1AppendedPages;
    public TextAsset[] answer2AppendedPages;
    public TextAsset[] answer3AppendedPages;

    public TextAsset finalReport;
    public TextAsset questionArchive;

    private WWW tempSite;

    /*

    IEnumerator ScrapeOverTime(int q, int questions)
    {
        int waitTime;

        Debug.Log("Starting Question " + q);

        if (q >= questions)
        {
            Debug.Log("FINISHED SCRAPING ALL DATA!");
            yield break;
        }

        waitTime = UnityEngine.Random.Range(30, 90);

        yield return new WaitForSeconds(waitTime);

        StartCoroutine(GrabWebPage(q));

        Debug.Log("Finished Question " + q);

        StartCoroutine(ScrapeOverTime(q + 1, questions));
    }

    IEnumerator GrabWebPage(int questionIndex)
    {
        int i;

        tempSite = new WWW("https://www.google.com/search?q=" + questionBank[questionIndex].question + "&num=75&filter=0&hl=en");
        yield return tempSite;
        WriteToTextFile(Application.dataPath + "/Screenshots/questions/question" + questionIndex + ".txt", tempSite.text);

        for (i = 0; i < 3; i++)
        {
            tempSite = new WWW("https://www.google.com/search?q=" + questionBank[questionIndex].question + " \"" + questionBank[questionIndex].answers[i] + "\"" + "&num=1&hl=en");
            yield return tempSite;
            WriteToTextFile(Application.dataPath + "/Screenshots/appendedanswer" + i + "/appendedanswer" + i + "-" + questionIndex + ".txt", tempSite.text);
        }
    }


    void GatherQuestionsAndTest()
    {
        int i, j;
        int cwi = 0, temp;
        int questionCount = 599;
        string questionArchiveText;

        questionArchiveText = questionArchive.text;

        for (i = 0; i < questionCount; i++)
        {
            temp = questionArchiveText.IndexOf("\n", cwi + 1);
            questionBank[i].question = questionArchiveText.Substring(cwi, temp - cwi);
            questionBank[i].question = questionBank[i].question.Replace("&amp;", "and");
            cwi = temp;
            for (j = 0; j < 3; j++)
            {
                cwi += 4;
                temp = questionArchiveText.IndexOf("\n", cwi + 1);
                questionBank[i].answers[j] = questionArchiveText.Substring(cwi, temp - cwi).Replace("\t", "");
                cwi = temp;
                if (questionBank[i].answers[j][questionBank[i].answers[j].Length - 2] == '~')
                    questionBank[i].correctA = j;
                questionBank[i].answers[j] = questionBank[i].answers[j].Replace('\r', '~');
                questionBank[i].answers[j] = questionBank[i].answers[j].Replace("~", "");
                questionBank[i].answers[j] = questionBank[i].answers[j].Replace("&amp;", "and");
                questionBank[i].answers[j] = questionBank[i].answers[j].Replace(".", "");
                //questionBank[i].answers[j] = questionBank[i].answers[j].Replace("\r", "");
            }
            cwi += 1;
        }

        //Debug.Log("Confidence: " + AnswerConfidence(new float[] { 11500, 38900, 14500 }, true, questionBank[456]));

        //StartCoroutine(ScrapeOverTime(587, 600));
    }

    void WriteToTextFile(TextAsset txt, string text, bool append)
    {
        string path = AssetDatabase.GetAssetPath(txt);
        StreamWriter writer = new StreamWriter(path, append);
        writer.WriteLine(text);
        writer.Close();
    }

    void WriteToTextFile(string filepath, string text)
    {
        StreamWriter writer = File.CreateText(filepath);
        writer.WriteLine(text);
        writer.Close();
    }

    void RunTestData()
    {
        bool finalTest = true;
        float[] method1Nums = new float[3];
        float[] method2Nums = new float[3];
        float[] method3Nums = new float[3];
        float[] finalMethodNums = new float[3];
        int finalCorrectCount = 0;

        int methodToUse;

        int i, j, n, m, k, ifIHaveToMakeOneMoreFreakingVariableISwear;
        float[] nums = new float[3];
        float[] sortedNums = new float[3];
        int guess = 0;
        float guessNum;
        bool correct = false;

        float[] method1_TopAnswerZones = new float[16];
        float[] method1_RunnerupAnswerZones = new float[16];
        float[] method1_TwoMinuesOneZones = new float[16];
        float[] method1_TwoOneRatioZones = new float[10];
        float[] method1_TopPopZones = new float[8];
        float[] method1_RunnerupPopZones = new float[8];
        float[] method1_TwoPopMinusOnePopZones = new float[10];
        float[] method1_SplitTwoPopMinusOnePopZones = new float[10];
        float[] method1_MaxAnswerWordsZones = new float[8];
        float[] method1_RelativeQuestion = new float[4];

        float[] method2_TopAnswerZones = new float[16];
        float[] method2_RunnerupAnswerZones = new float[16];
        float[] method2_TwoMinuesOneZones = new float[16];
        float[] method2_TwoOneRatioZones = new float[10];
        float[] method2_TopPopZones = new float[8];
        float[] method2_RunnerupPopZones = new float[8];
        float[] method2_TwoPopMinusOnePopZones = new float[10];
        float[] method2_SplitTwoPopMinusOnePopZones = new float[10];
        float[] method2_MaxAnswerWordsZones = new float[8];
        float[] method2_RelativeQuestion = new float[4];
        int temp1, temp2, temp3;

        //0-10 | 10-100 | 100-1k | 1k-10k | 10k-100k | 100k-500k | 500k-1m | 1m-5m| 5m+
        float[] method3_TopAnswerZones = new float[18];
        float[] method3_RunnerupAnswerZones = new float[18];
        float[] method3_TwoMinuesOneZones = new float[18];
        float[] method3_TwoOneRatioZones = new float[10];
        float[] method3_TopPopZones = new float[8];
        float[] method3_RunnerupPopZones = new float[8];
        float[] method3_TwoPopMinusOnePopZones = new float[10];
        float[] method3_MaxAnswerWordsZones = new float[8];
        float[] method3_RelativeQuestion = new float[4];

        string[] answerSplitWords;
        int answerSplitWordTotal = 0;
        int articleCount = 0;
        bool foundArticle = false;

        int[] methodsCorrectCount = new int[3];

        string suggestedAnswer;
        int SAguess;
        int SAattemptCount = 0;
        float SAcorrectCount = 0.0f;

        int qCount;

        qCount = questionPages.Length;
        popularWords = popularWordListText.text;

        //Detect inverted questions
        for (i = 0; i < qCount; i++)
            questionBank[i].invert = questionBank[i].question.Contains("NOT") || questionBank[i].question.Contains("NEVER");

        //Clear out anything already in the text file, and start with dividing lines
        WriteToTextFile(finalReport, "===============================================================================================================================================================", false);
        if (finalTest)
            WriteToTextFile(finalReport, "FINAL TEST", true);
        if (!finalTest)
            WriteToTextFile(finalReport, "RAW DATA", true);
        WriteToTextFile(finalReport, "===============================================================================================================================================================", true);

        //For each question...
        for (i = 0; i < qCount; i++)
        {
            methodToUse = 0;
            //Print out the header for the question
            WriteToTextFile(finalReport, String.Format("[Q{5}] {0} | {1} | {2} | {3} | Correct: {4}",
                questionBank[i].question, questionBank[i].answers[0], questionBank[i].answers[1], questionBank[i].answers[2], questionBank[i].correctA + 1, i + 1), true);

            //Try to get a suggested answer
            SAguess = -1;
            suggestedAnswer = SearchForSuggestedAnswer(questionPages[i].text);
            if (suggestedAnswer != "Not Available")
            {
                if (String.Equals(suggestedAnswer, questionBank[i].answers[0], StringComparison.OrdinalIgnoreCase))
                    SAguess = 0;
                else if (String.Equals(suggestedAnswer, questionBank[i].answers[1], StringComparison.OrdinalIgnoreCase))
                    SAguess = 1;
                else if (String.Equals(suggestedAnswer, questionBank[i].answers[2], StringComparison.OrdinalIgnoreCase))
                    SAguess = 2;
            }
            if (SAguess != -1)
            {
                Debug.Log("Got a suggested answer for question " + i + ", " + questionBank[i].question);
                if (SAguess == questionBank[i].correctA)
                    SAcorrectCount++;
                SAattemptCount++;
            }

            //For each search method...
            for (j = 0; j < 3; j++)
            {
                //Case by case, calculate the numbers for each method
                //Top 5 weighted keyphrase match
                if (j == 0)
                {
                    nums[0] = WordMatchCount(questionPages[i].text, questionBank[i].answers[0], 2);
                    nums[1] = WordMatchCount(questionPages[i].text, questionBank[i].answers[1], 2);
                    nums[2] = WordMatchCount(questionPages[i].text, questionBank[i].answers[2], 2);
                    for (k = 0; k < 3; k++) sortedNums[k] = method1Nums[k] = nums[k];
                    Array.Sort(sortedNums);

                    if (!questionBank[i].invert && sortedNums[2] - sortedNums[1] <= 1 ||
                       questionBank[i].invert && sortedNums[1] - sortedNums[0] <= 1)
                        methodToUse = 2;
                }
                //split keyword match
                if (j == 1)
                {
                    for (k = 0; k < 3; k++)
                    {
                        answerSplitWordTotal = articleCount = 0;
                        foundArticle = false;
                        answerSplitWords = questionBank[i].answers[k].Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
                        for (n = 0; n < answerSplitWords.Length; n++)
                        {
                            foundArticle = false;
                            for (m = 0; m < articles.Length; m++)
                            {
                                if (String.Equals(answerSplitWords[n], articles[m], StringComparison.OrdinalIgnoreCase))
                                {
                                    foundArticle = true;
                                    articleCount++;
                                }
                            }
                            if (!foundArticle)
                                answerSplitWordTotal += WordMatchCount(questionPages[i].text, answerSplitWords[n].Replace(" ", ""), 0);
                        }
                        try { answerSplitWordTotal /= (answerSplitWords.Length - articleCount); }
                        catch { answerSplitWordTotal = 0; }
                        nums[k] = answerSplitWordTotal;
                        sortedNums[k] = method2Nums[k] = nums[k];
                    }
                    Array.Sort(sortedNums);
                }
                //appended search quantity
                if (j == 2)
                {
                    nums[0] = GetAnswerQuantity(answer1AppendedPages[i].text);
                    nums[1] = GetAnswerQuantity(answer2AppendedPages[i].text);
                    nums[2] = GetAnswerQuantity(answer3AppendedPages[i].text);

                    for (k = 0; k < 3; k++) sortedNums[k] = method3Nums[k] = nums[k];
                    Array.Sort(sortedNums);
                }

                //////////////////////////////////////////////////////////////////////

                //Determine guess
                if (questionBank[i].invert == false)
                    guessNum = Mathf.Max(nums);
                else
                    guessNum = Mathf.Min(nums);
                if (Mathf.Abs(guessNum - nums[0]) < 0.01f) guess = 0;
                else if (Mathf.Abs(guessNum - nums[1]) < 0.01f) guess = 1;
                else guess = 2;
                //Determine correctness
                correct = (guess == questionBank[i].correctA);
                if (correct) methodsCorrectCount[j]++;

                //////////////////////////////////////////////////////////////////////

                //Determine more advanced stats (if not running final test)
                if (finalTest) goto DoneWithAdvancedStats;

                if (j == 0)
                {
                    //Top answer (zones)
                    if (!questionBank[i].invert)
                    {
                        k = 0;
                        if (guessNum >= 0 && guessNum < 5)
                            k = 0;
                        if (guessNum >= 5 && guessNum < 20)
                            k = 1;
                        if (guessNum >= 20 && guessNum < 45)
                            k = 2;
                        if (guessNum >= 45 && guessNum < 70)
                            k = 3;
                        if (guessNum >= 70 && guessNum < 100)
                            k = 4;
                        if (guessNum >= 100 && guessNum < 120)
                            k = 5;
                        if (guessNum >= 120 && guessNum < 140)
                            k = 6;
                        if (guessNum >= 140)
                            k = 7;
                        method1_TopAnswerZones[k + 8]++;
                        if (correct) method1_TopAnswerZones[k]++;
                    }
                    //Runnerup answer (zones)
                    if (!questionBank[i].invert)
                    {
                        k = 0;
                        if (sortedNums[1] >= 0 && sortedNums[1] < 5)
                            k = 0;
                        if (sortedNums[1] >= 5 && sortedNums[1] < 20)
                            k = 1;
                        if (sortedNums[1] >= 20 && sortedNums[1] < 45)
                            k = 2;
                        if (sortedNums[1] >= 45 && sortedNums[1] < 70)
                            k = 3;
                        if (sortedNums[1] >= 70 && sortedNums[1] < 100)
                            k = 4;
                        if (sortedNums[1] >= 100 && sortedNums[1] < 120)
                            k = 5;
                        if (sortedNums[1] >= 120 && sortedNums[1] < 140)
                            k = 6;
                        if (sortedNums[1] >= 140)
                            k = 7;
                        method1_RunnerupAnswerZones[k + 8]++;
                        if (correct) method1_RunnerupAnswerZones[k]++;
                    }
                    //Two minus one (zones)
                    if (!questionBank[i].invert)
                    {
                        k = 0;
                        if (sortedNums[2] - sortedNums[1] >= 0 && sortedNums[2] - sortedNums[1] < 5)
                            k = 0;
                        if (sortedNums[2] - sortedNums[1] >= 5 && sortedNums[2] - sortedNums[1] < 20)
                            k = 1;
                        if (sortedNums[2] - sortedNums[1] >= 20 && sortedNums[2] - sortedNums[1] < 45)
                            k = 2;
                        if (sortedNums[2] - sortedNums[1] >= 45 && sortedNums[2] - sortedNums[1] < 70)
                            k = 3;
                        if (sortedNums[2] - sortedNums[1] >= 70 && sortedNums[2] - sortedNums[1] < 100)
                            k = 4;
                        if (sortedNums[2] - sortedNums[1] >= 100 && sortedNums[2] - sortedNums[1] < 120)
                            k = 5;
                        if (sortedNums[2] - sortedNums[1] >= 120 && sortedNums[2] - sortedNums[1] < 140)
                            k = 6;
                        if (sortedNums[2] - sortedNums[1] >= 140)
                            k = 7;
                        method1_TwoMinuesOneZones[k + 8]++;
                        if (correct) method1_TwoMinuesOneZones[k]++;
                    }
                    //Two one ratio (zones)
                    if (!questionBank[i].invert)
                    {
                        k = 0;
                        if (sortedNums[1] / sortedNums[2] >= 0 && sortedNums[1] / sortedNums[2] < 0.2f)
                            k = 0;
                        if (sortedNums[1] / sortedNums[2] >= 0.2f && sortedNums[1] / sortedNums[2] < 0.4f)
                            k = 1;
                        if (sortedNums[1] / sortedNums[2] >= 0.4f && sortedNums[1] / sortedNums[2] < 0.6f)
                            k = 2;
                        if (sortedNums[1] / sortedNums[2] >= 0.6f && sortedNums[1] / sortedNums[2] < 0.8f)
                            k = 3;
                        if (sortedNums[1] / sortedNums[2] >= 0.8f)
                            k = 4;
                        method1_TwoOneRatioZones[k + 5]++;
                        if (correct) method1_TwoOneRatioZones[k]++;
                    }
                    //Top popularity (zones)
                    if (!questionBank[i].invert)
                    {
                        k = 0;
                        if (WordPopularity(questionBank[i].answers[guess]) >= 0 && WordPopularity(questionBank[i].answers[guess]) < 2500)
                            k = 0;
                        if (WordPopularity(questionBank[i].answers[guess]) >= 2500 && WordPopularity(questionBank[i].answers[guess]) < 5000)
                            k = 1;
                        if (WordPopularity(questionBank[i].answers[guess]) >= 5000 && WordPopularity(questionBank[i].answers[guess]) < 7500)
                            k = 2;
                        if (WordPopularity(questionBank[i].answers[guess]) >= 7500)
                            k = 3;
                        method1_TopPopZones[k + 4]++;
                        if (correct) method1_TopPopZones[k]++;
                    }
                    //Runnerup popularity (zones)
                    if (!questionBank[i].invert)
                    {
                        k = m = 0;
                        for (n = 0; n < 3; n++)
                        {
                            if (Mathf.Abs(nums[n] - sortedNums[1]) <= 0.01f)
                                m = n;
                        }
                        if (WordPopularity(questionBank[i].answers[m]) >= 0 && WordPopularity(questionBank[i].answers[guess]) < 2500)
                            k = 0;
                        if (WordPopularity(questionBank[i].answers[m]) >= 2500 && WordPopularity(questionBank[i].answers[guess]) < 5000)
                            k = 1;
                        if (WordPopularity(questionBank[i].answers[m]) >= 5000 && WordPopularity(questionBank[i].answers[guess]) < 7500)
                            k = 2;
                        if (WordPopularity(questionBank[i].answers[m]) >= 7500)
                            k = 3;
                        method1_RunnerupPopZones[k + 4]++;
                        if (correct) method1_RunnerupPopZones[k]++;
                    }
                    //Runnerup minus guess popularity (zones)
                    if (!questionBank[i].invert)
                    {
                        k = m = 0;
                        for (n = 0; n < 3; n++)
                        {
                            if (Mathf.Abs(nums[n] - sortedNums[1]) <= 0.01f)
                                m = n;
                        }

                        temp1 = WordPopularity(questionBank[i].answers[m]);
                        temp2 = WordPopularity(questionBank[i].answers[guess]);
                        temp3 = Mathf.Abs(temp1 - temp2);

                        if (temp3 >= 0 && temp3 < 1)
                            k = 0;
                        else if (temp3 >= 1 && temp3 < 2500)
                            k = 1;
                        else if (temp3 >= 2500 && temp3 < 5000)
                            k = 2;
                        else if (temp3 >= 5000 && temp3 < 7500)
                            k = 3;
                        else
                            k = 4;

                        method1_TwoPopMinusOnePopZones[k + 5]++;
                        if (correct) method1_TwoPopMinusOnePopZones[k]++;
                    }
                    //Split Runnerup minus guess popularity (zones)
                    if (!questionBank[i].invert)
                    {
                        k = m = 0;
                        for (n = 0; n < 3; n++)
                        {
                            if (Mathf.Abs(nums[n] - sortedNums[1]) <= 0.01f)
                                m = n;
                        }

                        temp1 = WordPopularity(questionBank[i].answers[m]);
                        temp2 = WordPopularity(questionBank[i].answers[guess]);

                        temp3 = Mathf.Abs(temp1 - temp2);

                        if (temp3 >= 0 && temp3 < 1)
                            k = 0;
                        else if (temp3 >= 1 && temp3 < 2500)
                            k = 1;
                        else if (temp3 >= 2500 && temp3 < 5000)
                            k = 2;
                        else if (temp3 >= 5000 && temp3 < 7500)
                            k = 3;
                        else
                            k = 4;

                        method1_TwoPopMinusOnePopZones[k + 5]++;
                        if (correct) method1_TwoPopMinusOnePopZones[k]++;
                    }
                    //Max word count (zones)
                    if (!questionBank[i].invert)
                    {
                        k = Mathf.Max(questionBank[i].answers[0].Count(c => c == ' '),
                                      questionBank[i].answers[1].Count(c => c == ' '),
                                      questionBank[i].answers[2].Count(c => c == ' '));
                        if (k > 3) k = 3;
                        method1_MaxAnswerWordsZones[k + 4]++;
                        if (correct) method1_MaxAnswerWordsZones[k]++;
                    }
                    //Relative question (zones)
                    if (IsRelativeQuestion(questionBank[i].question))
                    {
                        method1_RelativeQuestion[0 + 2]++;
                        if (correct) method1_RelativeQuestion[0]++;
                    }
                    else
                    {
                        method1_RelativeQuestion[1 + 2]++;
                        if (correct) method1_RelativeQuestion[1]++;
                    }
                }
                /////////////////////////////////////////////////////////////METHOD2
                if (j == 1)
                {
                    //Top answer (zones)
                    if (!questionBank[i].invert)
                    {
                        k = 0;
                        if (guessNum >= 0 && guessNum < 5)
                            k = 0;
                        if (guessNum >= 5 && guessNum < 20)
                            k = 1;
                        if (guessNum >= 20 && guessNum < 45)
                            k = 2;
                        if (guessNum >= 45 && guessNum < 70)
                            k = 3;
                        if (guessNum >= 70 && guessNum < 100)
                            k = 4;
                        if (guessNum >= 100 && guessNum < 120)
                            k = 5;
                        if (guessNum >= 120 && guessNum < 140)
                            k = 6;
                        if (guessNum >= 140)
                            k = 7;
                        method2_TopAnswerZones[k + 8]++;
                        if (correct) method2_TopAnswerZones[k]++;
                    }
                    //Runnerup answer (zones)
                    if (!questionBank[i].invert)
                    {
                        k = 0;
                        if (sortedNums[1] >= 0 && sortedNums[1] < 5)
                            k = 0;
                        if (sortedNums[1] >= 5 && sortedNums[1] < 20)
                            k = 1;
                        if (sortedNums[1] >= 20 && sortedNums[1] < 45)
                            k = 2;
                        if (sortedNums[1] >= 45 && sortedNums[1] < 70)
                            k = 3;
                        if (sortedNums[1] >= 70 && sortedNums[1] < 100)
                            k = 4;
                        if (sortedNums[1] >= 100 && sortedNums[1] < 120)
                            k = 5;
                        if (sortedNums[1] >= 120 && sortedNums[1] < 140)
                            k = 6;
                        if (sortedNums[1] >= 140)
                            k = 7;
                        method2_RunnerupAnswerZones[k + 8]++;
                        if (correct) method2_RunnerupAnswerZones[k]++;
                    }
                    //Two minus one (zones)
                    if (!questionBank[i].invert)
                    {
                        k = 0;
                        if (sortedNums[2] - sortedNums[1] >= 0 && sortedNums[2] - sortedNums[1] < 5)
                            k = 0;
                        if (sortedNums[2] - sortedNums[1] >= 5 && sortedNums[2] - sortedNums[1] < 20)
                            k = 1;
                        if (sortedNums[2] - sortedNums[1] >= 20 && sortedNums[2] - sortedNums[1] < 45)
                            k = 2;
                        if (sortedNums[2] - sortedNums[1] >= 45 && sortedNums[2] - sortedNums[1] < 70)
                            k = 3;
                        if (sortedNums[2] - sortedNums[1] >= 70 && sortedNums[2] - sortedNums[1] < 100)
                            k = 4;
                        if (sortedNums[2] - sortedNums[1] >= 100 && sortedNums[2] - sortedNums[1] < 120)
                            k = 5;
                        if (sortedNums[2] - sortedNums[1] >= 120 && sortedNums[2] - sortedNums[1] < 140)
                            k = 6;
                        if (sortedNums[2] - sortedNums[1] >= 140)
                            k = 7;
                        method2_TwoMinuesOneZones[k + 8]++;
                        if (correct) method2_TwoMinuesOneZones[k]++;
                    }
                    //Two one ratio (zones)
                    if (!questionBank[i].invert)
                    {
                        k = 0;
                        if (sortedNums[1] / sortedNums[2] >= 0 && sortedNums[1] / sortedNums[2] < 0.2f)
                            k = 0;
                        if (sortedNums[1] / sortedNums[2] >= 0.2f && sortedNums[1] / sortedNums[2] < 0.4f)
                            k = 1;
                        if (sortedNums[1] / sortedNums[2] >= 0.4f && sortedNums[1] / sortedNums[2] < 0.6f)
                            k = 2;
                        if (sortedNums[1] / sortedNums[2] >= 0.6f && sortedNums[1] / sortedNums[2] < 0.8f)
                            k = 3;
                        if (sortedNums[1] / sortedNums[2] >= 0.8f)
                            k = 4;
                        method2_TwoOneRatioZones[k + 5]++;
                        if (correct) method2_TwoOneRatioZones[k]++;
                    }
                    //Top popularity (zones)
                    if (!questionBank[i].invert)
                    {
                        k = 0;
                        if (WordPopularity(questionBank[i].answers[guess]) >= 0 && WordPopularity(questionBank[i].answers[guess]) < 2500)
                            k = 0;
                        if (WordPopularity(questionBank[i].answers[guess]) >= 2500 && WordPopularity(questionBank[i].answers[guess]) < 5000)
                            k = 1;
                        if (WordPopularity(questionBank[i].answers[guess]) >= 5000 && WordPopularity(questionBank[i].answers[guess]) < 7500)
                            k = 2;
                        if (WordPopularity(questionBank[i].answers[guess]) >= 7500)
                            k = 3;
                        method2_TopPopZones[k + 4]++;
                        if (correct) method2_TopPopZones[k]++;
                    }
                    //Runnerup popularity (zones)
                    if (!questionBank[i].invert)
                    {
                        k = m = 0;
                        for (n = 0; n < 3; n++)
                        {
                            if (Mathf.Abs(nums[n] - sortedNums[1]) <= 0.01f)
                                m = n;
                        }
                        if (WordPopularity(questionBank[i].answers[m]) >= 0 && WordPopularity(questionBank[i].answers[guess]) < 2500)
                            k = 0;
                        if (WordPopularity(questionBank[i].answers[m]) >= 2500 && WordPopularity(questionBank[i].answers[guess]) < 5000)
                            k = 1;
                        if (WordPopularity(questionBank[i].answers[m]) >= 5000 && WordPopularity(questionBank[i].answers[guess]) < 7500)
                            k = 2;
                        if (WordPopularity(questionBank[i].answers[m]) >= 7500)
                            k = 3;
                        method2_RunnerupPopZones[k + 4]++;
                        if (correct) method2_RunnerupPopZones[k]++;
                    }
                    //Split Runnerup minus guess popularity (zones)
                    if (!questionBank[i].invert)
                    {
                        k = m = 0;
                        for (n = 0; n < 3; n++)
                        {
                            if (Mathf.Abs(nums[n] - sortedNums[1]) <= 0.01f)
                                m = n;
                        }

                        answerSplitWordTotal = articleCount = 0;
                        foundArticle = false;
                        answerSplitWords = questionBank[i].answers[m].Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
                        for (n = 0; n < answerSplitWords.Length; n++)
                        {
                            foundArticle = false;
                            for (ifIHaveToMakeOneMoreFreakingVariableISwear = 0; ifIHaveToMakeOneMoreFreakingVariableISwear < articles.Length; ifIHaveToMakeOneMoreFreakingVariableISwear++)
                            {
                                if (String.Equals(answerSplitWords[n], articles[ifIHaveToMakeOneMoreFreakingVariableISwear], StringComparison.OrdinalIgnoreCase))
                                {
                                    foundArticle = true;
                                    articleCount++;
                                }
                            }
                            if (!foundArticle)
                                answerSplitWordTotal += WordPopularity(answerSplitWords[n]);
                        }
                        try { answerSplitWordTotal /= (answerSplitWords.Length - articleCount); }
                        catch { answerSplitWordTotal = 0; }
                        temp1 = answerSplitWordTotal;

                        answerSplitWordTotal = articleCount = 0;
                        foundArticle = false;
                        answerSplitWords = questionBank[i].answers[guess].Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
                        for (n = 0; n < answerSplitWords.Length; n++)
                        {
                            foundArticle = false;
                            for (ifIHaveToMakeOneMoreFreakingVariableISwear = 0; ifIHaveToMakeOneMoreFreakingVariableISwear < articles.Length; ifIHaveToMakeOneMoreFreakingVariableISwear++)
                            {
                                if (String.Equals(answerSplitWords[n], articles[ifIHaveToMakeOneMoreFreakingVariableISwear], StringComparison.OrdinalIgnoreCase))
                                {
                                    foundArticle = true;
                                    articleCount++;
                                }
                            }
                            if (!foundArticle)
                                answerSplitWordTotal += WordPopularity(answerSplitWords[n]);
                        }
                        try { answerSplitWordTotal /= (answerSplitWords.Length - articleCount); }
                        catch { answerSplitWordTotal = 0; }
                        temp2 = answerSplitWordTotal;

                        temp3 = Mathf.Abs(temp1 - temp2);

                        if (temp3 >= 0 && temp3 < 1)
                            k = 0;
                        else if (temp3 >= 1 && temp3 < 2500)
                            k = 1;
                        else if (temp3 >= 2500 && temp3 < 5000)
                            k = 2;
                        else if (temp3 >= 5000 && temp3 < 7500)
                            k = 3;
                        else
                            k = 4;
                        method2_SplitTwoPopMinusOnePopZones[k + 5]++;
                        if (correct) method2_SplitTwoPopMinusOnePopZones[k]++;
                    }
                    //Max word count (zones)
                    if (!questionBank[i].invert)
                    {
                        k = Mathf.Max(questionBank[i].answers[0].Count(c => c == ' '),
                                      questionBank[i].answers[1].Count(c => c == ' '),
                                      questionBank[i].answers[2].Count(c => c == ' '));
                        if (k > 3) k = 3;
                        method2_MaxAnswerWordsZones[k + 4]++;
                        if (correct) method2_MaxAnswerWordsZones[k]++;
                    }
                    //Relative question (zones)
                    if (IsRelativeQuestion(questionBank[i].question))
                    {
                        method2_RelativeQuestion[0 + 2]++;
                        if (correct) method2_RelativeQuestion[0]++;
                    }
                    else
                    {
                        method2_RelativeQuestion[1 + 2]++;
                        if (correct) method2_RelativeQuestion[1]++;
                    }
                }
                if (j == 2)
                {
                    //Top answer
                    if (!questionBank[i].invert)
                    {
                        k = 0;
                        if (guessNum >= 0 && guessNum < 10)
                            k = 0;
                        if (guessNum >= 10 && guessNum < 100)
                            k = 1;
                        if (guessNum >= 100 && guessNum < 1000)
                            k = 2;
                        if (guessNum >= 1000 && guessNum < 10000)
                            k = 3;
                        if (guessNum >= 10000 && guessNum < 100000)
                            k = 4;
                        if (guessNum >= 100000 && guessNum < 500000)
                            k = 5;
                        if (guessNum >= 500000 && guessNum < 1000000)
                            k = 6;
                        if (guessNum >= 1000000 && guessNum < 5000000)
                            k = 7;
                        if (guessNum >= 5000000)
                            k = 8;
                        method3_TopAnswerZones[k + 9]++;
                        if (correct) method3_TopAnswerZones[k]++;
                    }
                    //Runnerup answer
                    if (!questionBank[i].invert)
                    {
                        k = 0;
                        if (sortedNums[1] >= 0 && sortedNums[1] < 10)
                            k = 0;
                        if (sortedNums[1] >= 10 && sortedNums[1] < 100)
                            k = 1;
                        if (sortedNums[1] >= 100 && sortedNums[1] < 1000)
                            k = 2;
                        if (sortedNums[1] >= 1000 && sortedNums[1] < 10000)
                            k = 3;
                        if (sortedNums[1] >= 10000 && sortedNums[1] < 100000)
                            k = 4;
                        if (sortedNums[1] >= 100000 && sortedNums[1] < 500000)
                            k = 5;
                        if (sortedNums[1] >= 500000 && sortedNums[1] < 1000000)
                            k = 6;
                        if (sortedNums[1] >= 1000000 && sortedNums[1] < 5000000)
                            k = 7;
                        if (sortedNums[1] >= 5000000)
                            k = 8;
                        method3_RunnerupAnswerZones[k + 9]++;
                        if (correct) method3_RunnerupAnswerZones[k]++;
                    }
                    //Two minus one (zones)
                    if (!questionBank[i].invert)
                    {
                        k = 0;
                        if (sortedNums[2] - sortedNums[1] >= 0 && sortedNums[2] - sortedNums[1] < 10)
                            k = 0;
                        if (sortedNums[2] - sortedNums[1] >= 10 && sortedNums[2] - sortedNums[1] < 100)
                            k = 1;
                        if (sortedNums[2] - sortedNums[1] >= 100 && sortedNums[2] - sortedNums[1] < 1000)
                            k = 2;
                        if (sortedNums[2] - sortedNums[1] >= 1000 && sortedNums[2] - sortedNums[1] < 10000)
                            k = 3;
                        if (sortedNums[2] - sortedNums[1] >= 10000 && sortedNums[2] - sortedNums[1] < 100000)
                            k = 4;
                        if (sortedNums[2] - sortedNums[1] >= 100000 && sortedNums[2] - sortedNums[1] < 500000)
                            k = 5;
                        if (sortedNums[2] - sortedNums[1] >= 500000 && sortedNums[2] - sortedNums[1] < 1000000)
                            k = 6;
                        if (sortedNums[2] - sortedNums[1] >= 1000000 && sortedNums[2] - sortedNums[1] < 5000000)
                            k = 7;
                        if (sortedNums[2] - sortedNums[1] >= 5000000)
                            k = 8;
                        method3_TwoMinuesOneZones[k + 9]++;
                        if (correct) method3_TwoMinuesOneZones[k]++;
                    }
                    //Two one ratio (zones)
                    if (!questionBank[i].invert)
                    {
                        k = 0;
                        if (sortedNums[1] / sortedNums[2] >= 0 && sortedNums[1] / sortedNums[2] < 0.2f)
                            k = 0;
                        if (sortedNums[1] / sortedNums[2] >= 0.2f && sortedNums[1] / sortedNums[2] < 0.4f)
                            k = 1;
                        if (sortedNums[1] / sortedNums[2] >= 0.4f && sortedNums[1] / sortedNums[2] < 0.6f)
                            k = 2;
                        if (sortedNums[1] / sortedNums[2] >= 0.6f && sortedNums[1] / sortedNums[2] < 0.8f)
                            k = 3;
                        if (sortedNums[1] / sortedNums[2] >= 0.8f)
                            k = 4;
                        method3_TwoOneRatioZones[k + 5]++;
                        if (correct) method3_TwoOneRatioZones[k]++;
                    }
                    //Top popularity (zones)
                    if (!questionBank[i].invert)
                    {
                        k = 0;
                        if (WordPopularity(questionBank[i].answers[guess]) >= 0 && WordPopularity(questionBank[i].answers[guess]) < 2500)
                            k = 0;
                        if (WordPopularity(questionBank[i].answers[guess]) >= 2500 && WordPopularity(questionBank[i].answers[guess]) < 5000)
                            k = 1;
                        if (WordPopularity(questionBank[i].answers[guess]) >= 5000 && WordPopularity(questionBank[i].answers[guess]) < 7500)
                            k = 2;
                        if (WordPopularity(questionBank[i].answers[guess]) >= 7500)
                            k = 3;
                        method3_TopPopZones[k + 4]++;
                        if (correct) method3_TopPopZones[k]++;
                    }
                    //Runnerup popularity (zones)
                    if (!questionBank[i].invert)
                    {
                        k = m = 0;
                        for (n = 0; n < 3; n++)
                        {
                            if (Mathf.Abs(nums[n] - sortedNums[1]) <= 0.01f)
                                m = n;
                        }
                        if (WordPopularity(questionBank[i].answers[m]) >= 0 && WordPopularity(questionBank[i].answers[guess]) < 2500)
                            k = 0;
                        if (WordPopularity(questionBank[i].answers[m]) >= 2500 && WordPopularity(questionBank[i].answers[guess]) < 5000)
                            k = 1;
                        if (WordPopularity(questionBank[i].answers[m]) >= 5000 && WordPopularity(questionBank[i].answers[guess]) < 7500)
                            k = 2;
                        if (WordPopularity(questionBank[i].answers[m]) >= 7500)
                            k = 3;
                        method3_RunnerupPopZones[k + 4]++;
                        if (correct) method3_RunnerupPopZones[k]++;
                    }
                    //Runnerup minus guess popularity (zones)
                    if (!questionBank[i].invert)
                    {
                        k = m = 0;
                        for (n = 0; n < 3; n++)
                        {
                            if (Mathf.Abs(nums[n] - sortedNums[1]) <= 0.01f)
                                m = n;
                        }

                        temp1 = WordPopularity(questionBank[i].answers[m]);
                        temp2 = WordPopularity(questionBank[i].answers[guess]);
                        temp3 = Mathf.Abs(temp1 - temp2);

                        if (temp3 >= 0 && temp3 < 1)
                            k = 0;
                        else if (temp3 >= 1 && temp3 < 2500)
                            k = 1;
                        else if (temp3 >= 2500 && temp3 < 5000)
                            k = 2;
                        else if (temp3 >= 5000 && temp3 < 7500)
                            k = 3;
                        else
                            k = 4;

                        method3_TwoPopMinusOnePopZones[k + 5]++;
                        if (correct) method3_TwoPopMinusOnePopZones[k]++;
                    }
                    //Max word count (zones)
                    if (!questionBank[i].invert)
                    {
                        k = Mathf.Max(questionBank[i].answers[0].Count(c => c == ' '),
                                      questionBank[i].answers[1].Count(c => c == ' '),
                                      questionBank[i].answers[2].Count(c => c == ' '));
                        if (k > 3) k = 3;
                        method3_MaxAnswerWordsZones[k + 4]++;
                        if (correct) method3_MaxAnswerWordsZones[k]++;
                    }
                    //Relative question (zones)
                    if (IsRelativeQuestion(questionBank[i].question))
                    {
                        method3_RelativeQuestion[0 + 2]++;
                        if (correct) method3_RelativeQuestion[0]++;
                    }
                    else
                    {
                        method3_RelativeQuestion[1 + 2]++;
                        if (correct) method3_RelativeQuestion[1]++;
                    }
                }

                DoneWithAdvancedStats:
                //Print out the method's stats for a particular question
                WriteToTextFile(finalReport, String.Format("    -(M{5}) {0} | 1[{1:0.00}] | 2[{2:0.00}] | 3[{3:0.00}] | Guess:[{4}]", correct, nums[0], nums[1], nums[2], guess + 1, j + 1), true);
            }

            //Determine final guess
            if (methodToUse == 0)
                methodToUse = 1;

            if (((questionBank[i].answers[0].Count(c => c == ' ') + 1) +
                  (questionBank[i].answers[1].Count(c => c == ' ') + 1) +
                  (questionBank[i].answers[2].Count(c => c == ' ') + 1)) / (float)3 > 2.7f)
                methodToUse = 2;

            if (methodToUse == 1)
            {
                if (AnswerConfidence(method1Nums, false, questionBank[i]) < AnswerConfidence(method3Nums, true, questionBank[i]) && AnswerConfidence(method3Nums, true, questionBank[i]) >= 80)
                    methodToUse = 3;
            }
            if (methodToUse == 2)
            {
                if (AnswerConfidence(method2Nums, false, questionBank[i]) < AnswerConfidence(method3Nums, true, questionBank[i]) && AnswerConfidence(method3Nums, true, questionBank[i]) >= 80
                || Mathf.Max(method2Nums) == 0)
                    methodToUse = 3;
            }

            if (methodToUse == 1)
                finalMethodNums = method1Nums;
            if (methodToUse == 2)
                finalMethodNums = method2Nums;
            if (methodToUse == 3)
                finalMethodNums = method3Nums;

            if (!questionBank[i].invert)
                guessNum = Mathf.Max(finalMethodNums);
            else
                guessNum = Mathf.Min(finalMethodNums);

            for (k = 0; k < 3; k++)
            {
                if (Mathf.Abs(guessNum - finalMethodNums[k]) < 0.01f)
                    guess = k;
            }

            correct = false;
            if (guess == questionBank[i].correctA)
            {
                correct = true;
                finalCorrectCount++;
            }

            WriteToTextFile(finalReport, String.Format("    -Method Chosen: {0} | Guess:{1} | Correct: {2}", methodToUse, guess + 1, correct), true);
            WriteToTextFile(finalReport, String.Format("\n"), true);
        }

        //Generate Finals Report
        WriteToTextFile(finalReport, "===============================================================================================================================================================", true);
        WriteToTextFile(finalReport, "FINAL REPORT", true);
        WriteToTextFile(finalReport, "===============================================================================================================================================================", true);
        WriteToTextFile(finalReport, String.Format("Suggested Answer: {0} for {1} ({2}% accuracy)", SAcorrectCount, SAattemptCount, (SAcorrectCount / (float)SAattemptCount) * 100), true);
        for (i = 0; i < 3; i++)
            WriteToTextFile(finalReport, String.Format("Method {0} : {1}% accuracy", i + 1, (methodsCorrectCount[i] / (float)qCount) * 100), true);

        if (finalReport)
        {
            WriteToTextFile(finalReport, String.Format("Final Bot : {0}% accuracy", (finalCorrectCount / (float)qCount) * 100), true);
            goto YEET;
        }
        WriteToTextFile(finalReport, "===============================================================================================================================================================", true);
        WriteToTextFile(finalReport, "ADVANCED STATS", true);
        WriteToTextFile(finalReport, "===============================================================================================================================================================", true);
        WriteToTextFile(finalReport, "Method 1 Zones", true);
        WriteToTextFile(finalReport, "________________________________________________________________________________________________________________________________________________________________", true);
        WriteToTextFile(finalReport, String.Format("Top answer : [0 - 5, {0:0.00}] | [5 - 20, {1:0.00}] | [20 - 45, {2:0.00}] | [45 - 70, {3:0.00}] | [70 - 100, {4:0.00}] | [100 - 120, {5:0.00}] | [120 - 140, {6:0.00}] | [140+, {7:0.00}]",
            method1_TopAnswerZones[0] / method1_TopAnswerZones[0 + 8], method1_TopAnswerZones[1] / method1_TopAnswerZones[1 + 8], method1_TopAnswerZones[2] / method1_TopAnswerZones[2 + 8], method1_TopAnswerZones[3] / method1_TopAnswerZones[3 + 8],
            method1_TopAnswerZones[4] / method1_TopAnswerZones[4 + 8], method1_TopAnswerZones[5] / method1_TopAnswerZones[5 + 8], method1_TopAnswerZones[6] / method1_TopAnswerZones[6 + 8], method1_TopAnswerZones[7] / method1_TopAnswerZones[7 + 8]), true);
        WriteToTextFile(finalReport, String.Format("Runnerup answer : [0 - 5, {0:0.00}] | [5 - 20, {1:0.00}] | [20 - 45, {2:0.00}] | [45 - 70 {3:0.00}] | [70 - 100, {4:0.00}] | [100 - 120, {5:0.00}] | [120 - 140, {6:0.00}] | [140+, {7:0.00}]",
            method1_RunnerupAnswerZones[0] / method1_RunnerupAnswerZones[0 + 8], method1_RunnerupAnswerZones[1] / method1_RunnerupAnswerZones[1 + 8], method1_RunnerupAnswerZones[2] / method1_RunnerupAnswerZones[2 + 8], method1_RunnerupAnswerZones[3] / method1_RunnerupAnswerZones[3 + 8],
            method1_RunnerupAnswerZones[4] / method1_RunnerupAnswerZones[4 + 8], method1_RunnerupAnswerZones[5] / method1_RunnerupAnswerZones[5 + 8], method1_RunnerupAnswerZones[6] / method1_RunnerupAnswerZones[6 + 8], method1_RunnerupAnswerZones[7] / method1_RunnerupAnswerZones[7 + 8]), true);
        WriteToTextFile(finalReport, String.Format("Two minus one : [0 - 5, {0:0.00}] | [5 - 20, {1:0.00}] | [20 - 45, {2:0.00}] | [45 - 70 {3:0.00}] | [70 - 100, {4:0.00}] | [100 - 120, {5:0.00}] | [120 - 140, {6:0.00}] | [140+, {7:0.00}]",
            method1_TwoMinuesOneZones[0] / method1_TwoMinuesOneZones[0 + 8], method1_TwoMinuesOneZones[1] / method1_TwoMinuesOneZones[1 + 8], method1_TwoMinuesOneZones[2] / method1_TwoMinuesOneZones[2 + 8], method1_TwoMinuesOneZones[3] / method1_TwoMinuesOneZones[3 + 8],
            method1_TwoMinuesOneZones[4] / method1_TwoMinuesOneZones[4 + 8], method1_TwoMinuesOneZones[5] / method1_TwoMinuesOneZones[5 + 8], method1_TwoMinuesOneZones[6] / method1_TwoMinuesOneZones[6 + 8], method1_TwoMinuesOneZones[7] / method1_TwoMinuesOneZones[7 + 8]), true);
        WriteToTextFile(finalReport, String.Format("Two one ratio : [0% - 20%, {0:0.00}] | [20% - 40%, {1:0.00}] | [40% - 60%, {2:0.00}] | [60% - 80%, {3:0.00}] | [80% - 100%, {4:0.00}]",
            method1_TwoOneRatioZones[0] / method1_TwoOneRatioZones[0 + 5], method1_TwoOneRatioZones[1] / method1_TwoOneRatioZones[1 + 5], method1_TwoOneRatioZones[2] / method1_TwoOneRatioZones[2 + 5],
            method1_TwoOneRatioZones[3] / method1_TwoOneRatioZones[3 + 5], method1_TwoOneRatioZones[4] / method1_TwoOneRatioZones[4 + 5]), true);
        WriteToTextFile(finalReport, String.Format("Top popularity : [0 - 2500, {0:0.00}] | [2500 - 5000, {1:0.00}] | [5000 - 7500, {2:0.00}] | [7500+, {3:0.00}]",
            method1_TopPopZones[0] / method1_TopPopZones[0 + 4], method1_TopPopZones[1] / method1_TopPopZones[1 + 4], method1_TopPopZones[2] / method1_TopPopZones[2 + 4], method1_TopPopZones[3] / method1_TopPopZones[3 + 4]), true);
        WriteToTextFile(finalReport, String.Format("Runnerup popularity : [0 - 2500, {0:0.00}] | [2500 - 5000, {1:0.00}] | [5000 - 7500, {2:0.00}] | [7500+, {3:0.00}]",
            method1_RunnerupPopZones[0] / method1_RunnerupPopZones[0 + 4], method1_RunnerupPopZones[1] / method1_RunnerupPopZones[1 + 4], method1_RunnerupPopZones[2] / method1_RunnerupPopZones[2 + 4], method1_RunnerupPopZones[3] / method1_RunnerupPopZones[3 + 4]), true);
        WriteToTextFile(finalReport, String.Format("Runnerup popularity minus guess popularity : [0 - 1, {0:0.00}] | [1 - 2500, {1:0.00}] | [2500 - 5000, {2:0.00}] | [5000 - 7500, {3:0.00}] | [7500+, {4:0.00}]",
            method1_TwoPopMinusOnePopZones[0] / method1_TwoPopMinusOnePopZones[0 + 5], method1_TwoPopMinusOnePopZones[1] / method1_TwoPopMinusOnePopZones[1 + 5], method1_TwoPopMinusOnePopZones[2] / method1_TwoPopMinusOnePopZones[2 + 5],
            method1_TwoPopMinusOnePopZones[3] / method1_TwoPopMinusOnePopZones[3 + 5], method1_TwoPopMinusOnePopZones[4] / method1_TwoPopMinusOnePopZones[4 + 5]), true);
        WriteToTextFile(finalReport, String.Format("Highest word count in answers : [1, {0:0.00}] | [2, {1:0.00}] | [3, {2:0.00}] | [4+, {3:0.00}]",
            method1_MaxAnswerWordsZones[0] / method1_MaxAnswerWordsZones[0 + 4], method1_MaxAnswerWordsZones[1] / method1_MaxAnswerWordsZones[1 + 4], method1_MaxAnswerWordsZones[2] / method1_MaxAnswerWordsZones[2 + 4], method1_MaxAnswerWordsZones[3] / method1_MaxAnswerWordsZones[3 + 4]), true);
        WriteToTextFile(finalReport, String.Format("Relative Question : [True, {0:0.00}] | [False, {1:0.00}]",
            method1_RelativeQuestion[0] / method1_RelativeQuestion[0 + 2], method1_RelativeQuestion[1] / method1_RelativeQuestion[1 + 2]), true);
        WriteToTextFile(finalReport, "===============================================================================================================================================================", true);
        //////-----------------------------------------------------\\\\\\\
        WriteToTextFile(finalReport, "Method 2 Zones", true);
        WriteToTextFile(finalReport, "________________________________________________________________________________________________________________________________________________________________", true);
        WriteToTextFile(finalReport, String.Format("Top answer : [0 - 5, {0:0.00}] | [5 - 20, {1:0.00}] | [20 - 45, {2:0.00}] | [45 - 70, {3:0.00}] | [70 - 100, {4:0.00}] | [100 - 120, {5:0.00}] | [120 - 140, {6:0.00}] | [140+, {7:0.00}]",
            method2_TopAnswerZones[0] / method2_TopAnswerZones[0 + 8], method2_TopAnswerZones[1] / method2_TopAnswerZones[1 + 8], method2_TopAnswerZones[2] / method2_TopAnswerZones[2 + 8], method2_TopAnswerZones[3] / method2_TopAnswerZones[3 + 8],
            method2_TopAnswerZones[4] / method2_TopAnswerZones[4 + 8], method2_TopAnswerZones[5] / method2_TopAnswerZones[5 + 8], method2_TopAnswerZones[6] / method2_TopAnswerZones[6 + 8], method2_TopAnswerZones[7] / method2_TopAnswerZones[7 + 8]), true);
        WriteToTextFile(finalReport, String.Format("Runnerup answer : [0 - 5, {0:0.00}] | [5 - 20, {1:0.00}] | [20 - 45, {2:0.00}] | [45 - 70 {3:0.00}] | [70 - 100, {4:0.00}] | [100 - 120, {5:0.00}] | [120 - 140, {6:0.00}] | [140+, {7:0.00}]",
            method2_RunnerupAnswerZones[0] / method2_RunnerupAnswerZones[0 + 8], method2_RunnerupAnswerZones[1] / method2_RunnerupAnswerZones[1 + 8], method2_RunnerupAnswerZones[2] / method2_RunnerupAnswerZones[2 + 8], method2_RunnerupAnswerZones[3] / method2_RunnerupAnswerZones[3 + 8],
            method2_RunnerupAnswerZones[4] / method2_RunnerupAnswerZones[4 + 8], method2_RunnerupAnswerZones[5] / method2_RunnerupAnswerZones[5 + 8], method2_RunnerupAnswerZones[6] / method2_RunnerupAnswerZones[6 + 8], method2_RunnerupAnswerZones[7] / method2_RunnerupAnswerZones[7 + 8]), true);
        WriteToTextFile(finalReport, String.Format("Two minus one : [0 - 5, {0:0.00}] | [5 - 20, {1:0.00}] | [20 - 45, {2:0.00}] | [45 - 70 {3:0.00}] | [70 - 100, {4:0.00}] | [100 - 120, {5:0.00}] | [120 - 140, {6:0.00}] | [140+, {7:0.00}]",
            method2_TwoMinuesOneZones[0] / method2_TwoMinuesOneZones[0 + 8], method2_TwoMinuesOneZones[1] / method2_TwoMinuesOneZones[1 + 8], method2_TwoMinuesOneZones[2] / method2_TwoMinuesOneZones[2 + 8], method2_TwoMinuesOneZones[3] / method2_TwoMinuesOneZones[3 + 8],
            method2_TwoMinuesOneZones[4] / method2_TwoMinuesOneZones[4 + 8], method2_TwoMinuesOneZones[5] / method2_TwoMinuesOneZones[5 + 8], method2_TwoMinuesOneZones[6] / method2_TwoMinuesOneZones[6 + 8], method2_TwoMinuesOneZones[7] / method2_TwoMinuesOneZones[7 + 8]), true);
        WriteToTextFile(finalReport, String.Format("Two one ratio : [0% - 20%, {0:0.00}] | [20% - 40%, {1:0.00}] | [40% - 60%, {2:0.00}] | [60% - 80%, {3:0.00}] | [80% - 100%, {4:0.00}]",
            method2_TwoOneRatioZones[0] / method2_TwoOneRatioZones[0 + 5], method2_TwoOneRatioZones[1] / method2_TwoOneRatioZones[1 + 5], method2_TwoOneRatioZones[2] / method2_TwoOneRatioZones[2 + 5],
            method2_TwoOneRatioZones[3] / method2_TwoOneRatioZones[3 + 5], method2_TwoOneRatioZones[4] / method2_TwoOneRatioZones[4 + 5]), true);
        WriteToTextFile(finalReport, String.Format("Top popularity : [0 - 2500, {0:0.00}] | [2500 - 5000, {1:0.00}] | [5000 - 7500, {2:0.00}] | [7500+, {3:0.00}]",
            method2_TopPopZones[0] / method2_TopPopZones[0 + 4], method2_TopPopZones[1] / method2_TopPopZones[1 + 4], method2_TopPopZones[2] / method2_TopPopZones[2 + 4], method2_TopPopZones[3] / method2_TopPopZones[3 + 4]), true);
        WriteToTextFile(finalReport, String.Format("Runnerup popularity : [0 - 2500, {0:0.00}] | [2500 - 5000, {1:0.00}] | [5000 - 7500, {2:0.00}] | [7500+, {3:0.00}]",
            method2_RunnerupPopZones[0] / method2_RunnerupPopZones[0 + 4], method2_RunnerupPopZones[1] / method2_RunnerupPopZones[1 + 4], method2_RunnerupPopZones[2] / method2_RunnerupPopZones[2 + 4], method2_RunnerupPopZones[3] / method2_RunnerupPopZones[3 + 4]), true);
        WriteToTextFile(finalReport, String.Format("Split Runnerup popularity minus guess popularity : [0 - 1, {0:0.00}] | [1 - 2500, {1:0.00}] | [2500 - 5000, {2:0.00}] | [5000 - 7500, {3:0.00}] | [7500+, {4:0.00}]",
            method2_SplitTwoPopMinusOnePopZones[0] / method2_SplitTwoPopMinusOnePopZones[0 + 5], method2_SplitTwoPopMinusOnePopZones[1] / method2_SplitTwoPopMinusOnePopZones[1 + 5], method2_SplitTwoPopMinusOnePopZones[2] / method2_SplitTwoPopMinusOnePopZones[2 + 5],
            method2_SplitTwoPopMinusOnePopZones[3] / method2_SplitTwoPopMinusOnePopZones[3 + 5], method2_SplitTwoPopMinusOnePopZones[4] / method2_SplitTwoPopMinusOnePopZones[4 + 5]), true);
        WriteToTextFile(finalReport, String.Format("Highest word count in answers : [1, {0:0.00}] | [2, {1:0.00}] | [3, {2:0.00}] | [4+, {3:0.00}]",
            method2_MaxAnswerWordsZones[0] / method2_MaxAnswerWordsZones[0 + 4], method2_MaxAnswerWordsZones[1] / method2_MaxAnswerWordsZones[1 + 4], method2_MaxAnswerWordsZones[2] / method2_MaxAnswerWordsZones[2 + 4], method2_MaxAnswerWordsZones[3] / method2_MaxAnswerWordsZones[3 + 4]), true);
        WriteToTextFile(finalReport, String.Format("Relative Question : [True, {0:0.00}] | [False, {1:0.00}]",
            method2_RelativeQuestion[0] / method2_RelativeQuestion[0 + 2], method2_RelativeQuestion[1] / method2_RelativeQuestion[1 + 2]), true);
        WriteToTextFile(finalReport, "===============================================================================================================================================================", true);
        //////-----------------------------------------------------\\\\\\\
        //0-10 | 10-100 | 100-1k | 1k-10k | 10k-100k | 100k-500k | 500k-1m | 1m-5m| 5m+

        WriteToTextFile(finalReport, "Method 3 Zones", true);
        WriteToTextFile(finalReport, "________________________________________________________________________________________________________________________________________________________________", true);
        WriteToTextFile(finalReport, String.Format("Top answer : [0 - 10, {0:0.00}] | [10 - 100, {1:0.00}] | [100 - 1k, {2:0.00}] | [1k - 10k, {3:0.00}] | [10k - 100k, {4:0.00}] | [100k - 500k, {5:0.00}] | [500k - 1m, {6:0.00}] | [1m - 5m, {7:0.00}] | [5m+, {8:0.00}]",
            method3_TopAnswerZones[0] / method3_TopAnswerZones[0 + 9], method3_TopAnswerZones[1] / method3_TopAnswerZones[1 + 9], method3_TopAnswerZones[2] / method3_TopAnswerZones[2 + 9], method3_TopAnswerZones[3] / method3_TopAnswerZones[3 + 9], method3_TopAnswerZones[4] / method3_TopAnswerZones[4 + 9],
            method3_TopAnswerZones[5] / method3_TopAnswerZones[5 + 9], method3_TopAnswerZones[6] / method3_TopAnswerZones[6 + 9], method3_TopAnswerZones[7] / method3_TopAnswerZones[7 + 9], method3_TopAnswerZones[8] / method3_TopAnswerZones[8 + 9]), true);
        WriteToTextFile(finalReport, String.Format("Runnerup answer : [0 - 10, {0:0.00}] | [10 - 100, {1:0.00}] | [100 - 1k, {2:0.00}] | [1k - 10k, {3:0.00}] | [10k - 100k, {4:0.00}] | [100k - 500k, {5:0.00}] | [500k - 1m, {6:0.00}] | [1m - 5m, {7:0.00}] | [5m+, {8:0.00}]",
            method3_RunnerupAnswerZones[0] / method3_RunnerupAnswerZones[0 + 9], method3_RunnerupAnswerZones[1] / method3_RunnerupAnswerZones[1 + 9], method3_RunnerupAnswerZones[2] / method3_RunnerupAnswerZones[2 + 9], method3_RunnerupAnswerZones[3] / method3_RunnerupAnswerZones[3 + 9], method3_RunnerupAnswerZones[4] / method3_RunnerupAnswerZones[4 + 9],
            method3_RunnerupAnswerZones[5] / method3_RunnerupAnswerZones[5 + 9], method3_RunnerupAnswerZones[6] / method3_RunnerupAnswerZones[6 + 9], method3_RunnerupAnswerZones[7] / method3_RunnerupAnswerZones[7 + 9], method3_RunnerupAnswerZones[8] / method3_RunnerupAnswerZones[8 + 9]), true);
        WriteToTextFile(finalReport, String.Format("Top minus runnerup answer: [0 - 10, {0:0.00}] | [10 - 100, {1:0.00}] | [100 - 1k, {2:0.00}] | [1k - 10k, {3:0.00}] | [10k - 100k, {4:0.00}] | [100k - 500k, {5:0.00}] | [500k - 1m, {6:0.00}] | [1m - 5m, {7:0.00}] | [5m+, {8:0.00}]",
            method3_TwoMinuesOneZones[0] / method3_TwoMinuesOneZones[0 + 9], method3_TwoMinuesOneZones[1] / method3_TwoMinuesOneZones[1 + 9], method3_TwoMinuesOneZones[2] / method3_TwoMinuesOneZones[2 + 9], method3_TwoMinuesOneZones[3] / method3_TwoMinuesOneZones[3 + 9], method3_TwoMinuesOneZones[4] / method3_TwoMinuesOneZones[4 + 9],
            method3_TwoMinuesOneZones[5] / method3_TwoMinuesOneZones[5 + 9], method3_TwoMinuesOneZones[6] / method3_TwoMinuesOneZones[6 + 9], method3_TwoMinuesOneZones[7] / method3_TwoMinuesOneZones[7 + 9], method3_TwoMinuesOneZones[8] / method3_TwoMinuesOneZones[8 + 9]), true);
        WriteToTextFile(finalReport, String.Format("Two one ratio : [0% - 20%, {0:0.00}] | [20% - 40%, {1:0.00}] | [40% - 60%, {2:0.00}] | [60% - 80%, {3:0.00}] | [80% - 100%, {4:0.00}]",
            method3_TwoOneRatioZones[0] / method3_TwoOneRatioZones[0 + 5], method3_TwoOneRatioZones[1] / method3_TwoOneRatioZones[1 + 5], method3_TwoOneRatioZones[2] / method3_TwoOneRatioZones[2 + 5],
            method3_TwoOneRatioZones[3] / method3_TwoOneRatioZones[3 + 5], method3_TwoOneRatioZones[4] / method3_TwoOneRatioZones[4 + 5]), true);
        WriteToTextFile(finalReport, String.Format("Top popularity : [0 - 2500, {0:0.00}] | [2500 - 5000, {1:0.00}] | [5000 - 7500, {2:0.00}] | [7500+, {3:0.00}]",
            method3_TopPopZones[0] / method3_TopPopZones[0 + 4], method3_TopPopZones[1] / method3_TopPopZones[1 + 4], method3_TopPopZones[2] / method3_TopPopZones[2 + 4], method3_TopPopZones[3] / method3_TopPopZones[3 + 4]), true);
        WriteToTextFile(finalReport, String.Format("Runnerup popularity : [0 - 2500, {0:0.00}] | [2500 - 5000, {1:0.00}] | [5000 - 7500, {2:0.00}] | [7500+, {3:0.00}]",
            method3_RunnerupPopZones[0] / method3_RunnerupPopZones[0 + 4], method3_RunnerupPopZones[1] / method3_RunnerupPopZones[1 + 4], method3_RunnerupPopZones[2] / method3_RunnerupPopZones[2 + 4], method3_RunnerupPopZones[3] / method3_RunnerupPopZones[3 + 4]), true);
        WriteToTextFile(finalReport, String.Format("Runnerup popularity minus guess popularity : [0 - 1, {0:0.00}] | [1 - 2500, {1:0.00}] | [2500 - 5000, {2:0.00}] | [5000 - 7500, {3:0.00}] | [7500+, {4:0.00}]",
            method3_TwoPopMinusOnePopZones[0] / method3_TwoPopMinusOnePopZones[0 + 5], method3_TwoPopMinusOnePopZones[1] / method3_TwoPopMinusOnePopZones[1 + 5], method3_TwoPopMinusOnePopZones[2] / method3_TwoPopMinusOnePopZones[2 + 5],
            method3_TwoPopMinusOnePopZones[3] / method3_TwoPopMinusOnePopZones[3 + 5], method3_TwoPopMinusOnePopZones[4] / method3_TwoPopMinusOnePopZones[4 + 5]), true);

        WriteToTextFile(finalReport, String.Format("Highest word count in answers : [1, {0:0.00}] | [2, {1:0.00}] | [3, {2:0.00}] | [4+, {3:0.00}]",
            method3_MaxAnswerWordsZones[0] / method3_MaxAnswerWordsZones[0 + 4], method3_MaxAnswerWordsZones[1] / method3_MaxAnswerWordsZones[1 + 4], method3_MaxAnswerWordsZones[2] / method3_MaxAnswerWordsZones[2 + 4], method3_MaxAnswerWordsZones[3] / method3_MaxAnswerWordsZones[3 + 4]), true);
        WriteToTextFile(finalReport, String.Format("Relative Question : [True, {0:0.00}] | [False, {1:0.00}]",
            method3_RelativeQuestion[0] / method3_RelativeQuestion[0 + 2], method3_RelativeQuestion[1] / method3_RelativeQuestion[1 + 2]), true);

        YEET:
        WriteToTextFile(finalReport, "===============================================================================================================================================================", true);

        Debug.Log("FINAL REPORT GENERATED!");
    }

    */
}
