﻿using UnityEngine;

public class QusetionBank : MonoBehaviour {

    public Question[] questionBank;

}